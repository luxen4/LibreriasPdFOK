<?php

class Countries extends \Kumbia\ActiveRecord\LiteRecord
{
    static protected $database = 'countries';
}
