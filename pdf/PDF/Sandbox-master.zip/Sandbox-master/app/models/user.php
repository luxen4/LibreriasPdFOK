<?php

/**
 * Clase para manejar los datos del usuario, tabla 'user'
 */
class User extends \Kumbia\ActiveRecord\LiteRecord
{

}
