![KumbiaPHP logo](https://raw.githubusercontent.com/KumbiaPHP/KumbiaPHP/master/default/public/img/kumbiaphp.svg?sanitize=true)

# Sandbox
KumbiaPHP sandbox with examples.

## How to colaborate?
Send your examples :)
